using Microsoft.AspNetCore.Mvc;
using FutureValue.Models; // Make sure this matches your project's namespace

namespace FutureValue.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            // Sets the initial future value to 0 when the page first loads
            ViewBag.FV = 0;
            return View();
        }

        [HttpPost]
        public IActionResult Index(FutureValueModel model)
        {
            if (ModelState.IsValid)
            {
                // If the data passes validation, calculate and store the result
                ViewBag.FV = model.CalculateFutureValue();
            }
            else
            {
                // If there are errors (like missing data), reset the value to 0
                ViewBag.FV = 0;
            }

            // Returns the view, passing back the model so the user's inputs stay in the form
            return View(model);
        }
    }
}