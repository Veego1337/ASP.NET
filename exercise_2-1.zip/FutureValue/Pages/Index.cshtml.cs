using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FutureValue.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
