﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FutureValue.Pages
{
    public class PrivacyModel : PageModel
    {
        public void OnGet()
        {
        }
    }

}
