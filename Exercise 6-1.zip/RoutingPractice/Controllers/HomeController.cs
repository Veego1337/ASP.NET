﻿using Microsoft.AspNetCore.Mvc;

namespace RoutingPractice.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return Content("Home");
        }

        public IActionResult Privacy()
        {
            return Content("Privacy");
        }

        public IActionResult Display(string id)
        {
            if (id == null)
            {
                return Content("No ID supplied.");
            }
            else
            {
                return Content("ID: " + id);
            }
        }

        [Route("Countdown/{start}/{end}/{message}")]
        public IActionResult Countdown(int start, int end, string message)
        {
            string countdownResult = "";

            for (int i = start; i >= end; i--)
            {
                countdownResult += i + "\n";
            }

            countdownResult += message;

            return Content(countdownResult);
        }
    }
}