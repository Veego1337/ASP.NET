﻿namespace FutureValueEmpty.Models
{
    public class FutureValueModel
    {
    }
}
