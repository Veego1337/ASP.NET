﻿using Microsoft.AspNetCore.Mvc;

namespace FutureValueEmpty.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
