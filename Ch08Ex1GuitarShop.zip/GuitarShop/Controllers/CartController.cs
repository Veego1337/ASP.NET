﻿using Microsoft.AspNetCore.Mvc;

namespace GuitarShop.Controllers
{
    public class CartController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Add(string id)
        {
            // Add the message to TempData
            TempData["message"] = "Product was added to your cart.";

            // Redirect to the List action of the Product controller
            return RedirectToAction("List", "Product");
        }
    }
}