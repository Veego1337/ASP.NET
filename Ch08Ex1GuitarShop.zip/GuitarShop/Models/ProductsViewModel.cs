﻿using System.Collections.Generic;

namespace GuitarShop.Models
{
    public class ProductsViewModel
    {
        public List<Category> Categories { get; set; } = null!;
        public List<Product> Products { get; set; } = null!;
        public string SelectedCategory { get; set; } = null!;

        public string CheckActiveCategory(string category)
        {
            return category == SelectedCategory ? "active" : "";
        }
    }
}
