﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace GuitarShop.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        [Route("/ContactUs")]
        public IActionResult ContactUs()
        {
            var contactData = new Dictionary<string, string>()
            {
                { "Phone", "1-800-555-SHOP" },
                { "Email", "support@guitarshop.com" },
                { "Address", "123 Fender Ave, Nashville, TN 37203" }
            };

            return View(contactData);
        }
    }
}