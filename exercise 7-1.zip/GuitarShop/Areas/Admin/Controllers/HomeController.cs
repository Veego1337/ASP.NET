﻿using Microsoft.AspNetCore.Mvc;

namespace GuitarShop.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [Route("/ContactUs")]
        public IActionResult ContactUs()
        {
            var contactData = new Dictionary<string, string>()
    {
        { "Phone", "1-800-555-SHOP" },
        { "Email", "support@guitarshop.com" },
        { "Address", "123 Fender Ave, Nashville, TN 37203" }
    };

            // You MUST pass the 'contactData' variable here!
            return View(contactData);
        }
    }
}