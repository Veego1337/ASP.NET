﻿using Microsoft.AspNetCore.Mvc;
using ClassSchedule.Models;

namespace ClassSchedule.Controllers
{
    public class TeacherController : Controller
    {
        // 1. Use a private readonly field for the interface
        private readonly IRepository<Teacher> _repository;

        // 2. Inject the interface via the constructor instead of the DbContext
        public TeacherController(IRepository<Teacher> repository)
        {
            _repository = repository;
        }

        public ViewResult Index()
        {
            var options = new QueryOptions<Teacher>
            {
                OrderBy = t => t.LastName
            };
            // 3. Update 'teachers' to '_repository'
            return View(_repository.List(options));
        }

        [HttpGet]
        public ViewResult Add() => View();

        [HttpPost]
        public IActionResult Add(Teacher teacher)
        {
            if (ModelState.IsValid)
            {
                _repository.Insert(teacher);
                _repository.Save();
                return RedirectToAction("Index");
            }
            else
            {
                return View(teacher);
            }
        }

        [HttpGet]
        public ViewResult Delete(int id) => View(_repository.Get(id));

        [HttpPost]
        public RedirectToActionResult Delete(Teacher teacher)
        {
            _repository.Delete(teacher);
            _repository.Save();
            return RedirectToAction("Index");
        }
    }
}