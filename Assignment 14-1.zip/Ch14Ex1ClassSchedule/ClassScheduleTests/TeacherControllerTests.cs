﻿using Moq;
using Microsoft.AspNetCore.Mvc;
using ClassSchedule.Models;
using ClassSchedule.Controllers;
using Xunit;
using System.Collections.Generic; // Required for List<T>

namespace ClassScheduleTests
{
    public class TeacherControllerTests
    {
        [Fact]
        public void IndexActionMethod_ReturnsAViewResult()
        {
            // Arrange
            var mockRepo = new Mock<IRepository<Teacher>>();
            var controller = new TeacherController(mockRepo.Object);

            // Act
            var result = controller.Index();

            // Assert
            Assert.IsType<ViewResult>(result);
        }

        [Fact]
        public void IndexActionMethod_ModelIsAListOfTeacherObjects()
        {
            // Arrange
            var mockRepo = new Mock<IRepository<Teacher>>();

            // Set up the List() method to accept a QueryOptions<Teacher> object and return a List<Teacher> object
            mockRepo.Setup(repo => repo.List(It.IsAny<QueryOptions<Teacher>>()))
                    .Returns(new List<Teacher>());

            var controller = new TeacherController(mockRepo.Object);

            // Act
            var result = controller.Index();

            // Assert
            // Check that it returns a ViewResult
            var viewResult = Assert.IsType<ViewResult>(result);
            // Check that the Model property is of type List<Teacher>
            Assert.IsType<List<Teacher>>(viewResult.Model);
        }
    }
}
