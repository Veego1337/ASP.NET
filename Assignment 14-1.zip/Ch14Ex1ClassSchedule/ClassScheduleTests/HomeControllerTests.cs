﻿using Moq;
using Microsoft.AspNetCore.Mvc;
using ClassSchedule.Models;
using ClassSchedule.Controllers;
using Xunit;
using System.Collections.Generic;

namespace ClassScheduleTests
{
    // Make sure the class is public
    public class HomeControllerTests
    {
        [Fact]
        public void IndexActionMethod_ReturnsAViewResult()
        {
            // Arrange
            var days = new List<Day>();
            var classes = new List<Class>();

            var mockDayRepo = new Mock<IRepository<Day>>();
            var mockClassRepo = new Mock<IRepository<Class>>();

            // (Optional) Setup the mocks to return the lists if your controller calls them
            // mockDayRepo.Setup(m => m.List(It.IsAny<QueryOptions<Day>>())).Returns(days);
            // mockClassRepo.Setup(m => m.List(It.IsAny<QueryOptions<Class>>())).Returns(classes);

            // Pass both mocked objects in the same order the constructor expects them
            var controller = new HomeController(mockDayRepo.Object, mockClassRepo.Object);

            // Act
            var result = controller.Index(0);

            // Assert
            Assert.IsType<ViewResult>(result);
        }
    }
}