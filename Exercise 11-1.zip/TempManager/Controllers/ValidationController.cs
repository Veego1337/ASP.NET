﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using TempManager.Models;

namespace TempManager.Controllers
{
    public class ValidationController : Controller
    {
        private TempManagerContext context;

        public ValidationController(TempManagerContext ctx)
        {
            context = ctx;
        }

        public JsonResult CheckDate(string date)
        {
            if (DateTime.TryParse(date, out DateTime parsedDate))
            {
                var temp = context.Temps.FirstOrDefault(t => t.Date == parsedDate);

                if (temp == null)
                {
                    return Json(true);
                }
                else
                {
                    return Json($"A temperature reading for {parsedDate.ToShortDateString()} already exists.");
                }
            }

            return Json("Invalid date format.");
        }
    }
}