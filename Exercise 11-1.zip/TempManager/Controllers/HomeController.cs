﻿using System.Linq;
using Microsoft.AspNetCore.Mvc;
using TempManager.Models;

namespace TempManager.Controllers
{
    public class HomeController : Controller
    {
        private TempManagerContext context;

        public HomeController(TempManagerContext ctx)
        {
            context = ctx;
        }

        public IActionResult Index()
        {
            var temps = context.Temps.OrderByDescending(t => t.Date).ToList();
            return View(temps);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View(new Temp());
        }

        [HttpPost]
        public IActionResult Add(Temp temp)
        {
            // Server-Side Check For Remote Validation
            if (temp.Date.HasValue)
            {
                if (context.Temps.Any(t => t.Date == temp.Date))
                {
                    ModelState.AddModelError("Date", "A temperature reading for this date already exists.");
                }
            }

            if (ModelState.IsValid)
            {
                context.Temps.Add(temp);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                // Model-Level Error Message
                ModelState.AddModelError("", "Please correct all errors");
                return View(temp);
            }
        }
    }
}