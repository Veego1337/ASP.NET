using Microsoft.EntityFrameworkCore;
using TempManager.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

builder.Services.AddDbContext<TempManagerContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("TempManagerContext"), // Or your specific connection string name
        sqlServerOptionsAction: sqlOptions =>
        {
            sqlOptions.EnableRetryOnFailure(
                maxRetryCount: 5, // The maximum number of retry attempts
                maxRetryDelay: TimeSpan.FromSeconds(30), // The maximum delay between retries
                errorNumbersToAdd: null); // Additional SQL error numbers to consider transient
        }));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
