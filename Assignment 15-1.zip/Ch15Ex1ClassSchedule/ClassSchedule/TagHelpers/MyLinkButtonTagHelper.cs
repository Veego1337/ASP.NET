﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.AspNetCore.Routing;

namespace ClassSchedule.TagHelpers
{
    public class MyLinkButtonTagHelper : TagHelper
    {
        private LinkGenerator linkBuilder;

        public MyLinkButtonTagHelper(LinkGenerator linkGenerator)
        {
            linkBuilder = linkGenerator;
        }

        [ViewContext]
        [HtmlAttributeNotBound]
        public ViewContext ViewCtx { get; set; }

        public string Action { get; set; }
        public string Controller { get; set; }
        public string Id { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            // Assign Action and Controller properties or fallback to RouteData
            string action = Action ?? ViewCtx.RouteData.Values["action"]?.ToString();
            string controller = Controller ?? ViewCtx.RouteData.Values["controller"]?.ToString();

            // Create anonymous object for the id route segment
            var id = new { id = Id };

            // Create URL
            string url = linkBuilder.GetPathByAction(action, controller, id);

            // Determine CSS classes based on current route
            string css;
            if (ViewCtx.RouteData.Values["id"]?.ToString() == Id)
            {
                css = "btn btn-dark";
            }
            else
            {
                css = "btn btn-outline-dark";
            }

            // Transform element using the custom extension method
            output.BuildLink(url, css);
        }
    }
}