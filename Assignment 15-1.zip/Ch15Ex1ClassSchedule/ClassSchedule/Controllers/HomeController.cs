﻿using ClassSchedule.Models;
using Microsoft.AspNetCore.Mvc;

namespace ClassSchedule.Controllers
{
    public class HomeController : Controller
    {
        private IRepository<Class> classes { get; set; }

        // Removed the IRepository<Day> days property entirely

        public HomeController(IRepository<Class> rep)
        {
            // Changed "data = rep;" to match the property name
            classes = rep;
        }

        public IActionResult Index(int id)
        {
            // options for Classes query
            var classOptions = new QueryOptions<Class>
            {
                Includes = "Teacher, Day"
            };

            // order classes by day and then time on first load (ie, there's no filter value).
            // Otherwise, filter by day and order by time.
            if (id == 0)
            {
                classOptions.OrderBy = c => c.DayId;
                classOptions.ThenOrderBy = c => c.MilitaryTime;
            }
            else
            {
                classOptions.Where = c => c.DayId == id;
                classOptions.OrderBy = c => c.MilitaryTime;
            }

            // execute class query
            var classList = classes.List(classOptions);

            // Removed all Day query and ViewBag logic since the View Component handles it now

            ViewBag.Id = id;
            return View(classList);
        }
    }
}