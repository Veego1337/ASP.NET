﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;
using ClassSchedule.Models;

namespace ClassSchedule.Views.Shared.Components
{
    public class DayFilter : ViewComponent
    {
        private IRepository<Day> data;

        public DayFilter(IRepository<Day> rep)
        {
            data = rep;
        }

        public IViewComponentResult Invoke()
        {
            // Retrieves the collection and sorts by DayId
            var days = data.List(new QueryOptions<Day> { OrderBy = d => d.DayId });

            // Note: If you aren't using a QueryOptions pattern, 
            // use data.GetAll().OrderBy(d => d.DayId).ToList();

            return View(days);
        }
    }
}