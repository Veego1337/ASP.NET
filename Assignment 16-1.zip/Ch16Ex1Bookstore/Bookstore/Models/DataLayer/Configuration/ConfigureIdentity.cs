﻿using Bookstore.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Threading.Tasks;
// Ensure your models namespace is included, e.g., using Bookstore.Models;

public class ConfigureIdentity
{
    public static async Task CreateAdminUserAsync(IServiceProvider provider)
    {
        var roleManager = provider.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = provider.GetRequiredService<UserManager<User>>();

        if (await roleManager.FindByNameAsync("Admin") == null)
        {
            await roleManager.CreateAsync(new IdentityRole("Admin"));
        }

        if (await userManager.FindByNameAsync("admin") == null)
        {
            var user = new User
            {
                UserName = "admin",
                FirstName = "Admin",
                LastName = "User",
                Email = "admin@bookstore.com"
            };

            var result = await userManager.CreateAsync(user, "AdminSecret123!"); // Update with the specific password from Figure 16-22 if needed

            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(user, "Admin");
            }
        }
    }
}