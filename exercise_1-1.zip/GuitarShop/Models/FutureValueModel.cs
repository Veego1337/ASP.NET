﻿using System.ComponentModel.DataAnnotations;

namespace GuitarShop.Models
{
    public class FutureValueModel
    {
        [Required(ErrorMessage = "Please enter a monthly investment amount.")]
        [Range(1, 10000, ErrorMessage = "Monthly investment amount must be between 1 and 10000.")]
        public decimal? MonthlyInvestment { get; set; }

        [Required(ErrorMessage = "Please enter a yearly interest rate.")]
        [Range(0.1, 15.0, ErrorMessage = "Yearly interest rate must be between 0.1 and 15.0.")]
        public decimal? YearlyInterestRate { get; set; }

        [Required(ErrorMessage = "Please enter a number of years.")]
        [Range(1, 50, ErrorMessage = "Number of years must be between 1 and 50.")]
        public int? Years { get; set; }

        public decimal? CalculateFutureValue()
        {
            if (!MonthlyInvestment.HasValue || !YearlyInterestRate.HasValue || !Years.HasValue)
            {
                return 0;
            }

            int months = Years.Value * 12;
            decimal monthlyRate = YearlyInterestRate.Value / 12 / 100;
            decimal futureValue = 0;

            for (int i = 0; i < months; i++)
            {
                futureValue = (futureValue + MonthlyInvestment.Value) * (1 + monthlyRate);
            }

            return futureValue;
        }
    }
}